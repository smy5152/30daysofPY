greeting = "Hello, world"
print(f"{greeting}!")

name=input("Please enter you name: ").title().strip()
print(f"Hello, {name}!")

text="I am "
age = 29
print(f"{text}{str(age)}")

title = "Joker"
director = "Todd Phillips"
release_year = 2019

print(f"{title} ({release_year}), directed by {director}")