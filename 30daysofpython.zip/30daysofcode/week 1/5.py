# exercise 1,2
def print_ids(a,b,str1,str2):
  print(f"{bool(a==b)}", f" #1({str1}) ", id(a), f" #2({str2}) ", id(b))
  return True

numbers = [1, 2, 3, 4]
new_numbers = numbers + [5]
#print_ids(numbers, new_numbers, 'numbers', 'new_numbers')
numbers.append(5)
#print_ids(numbers, new_numbers, 'numbers', 'numbers_appended')

#exercise 3

def print_me(msg): 
  #print(f"You entered a {msg}.")
  return True

#uncomment this line to run
num=int(input("Enter a number: "))
if num==0:
  print_me("'Zero'")
elif num>0:
  print_me("'Positive' number")
elif num<0:
  print_me("'Negative' number")
else:
  print_me("Invalid Input")

#Exercise 4 - overtime
def check_overtime(wage, hours):
  message=""
  if hours>40:
    extra=(hours-40)*(wage)
    message="\n\tYou have some additional pay:" + str(extra+(extra*.1)) #+10%
  return message

while 1:
  print("Enter the following information:")
  name=input("Name: ").strip().lower().title()
  hourly_wage=float(input("Hourly Wage? : ").strip())
  weekly_work_hours=float(input("Hours worked this week? : ").strip())
  earnings=hourly_wage*weekly_work_hours
  print(f"\n Hello, {name}.\n You earn {hourly_wage} per hour.\n Your earnings this week: ${earnings:,.2f}")

  print(check_overtime(hourly_wage, weekly_work_hours))

  if input("Do you want to continue (Y/N)? : ").strip().lower() == 'n':
    break;



