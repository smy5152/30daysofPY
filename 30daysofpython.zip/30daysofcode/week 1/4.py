def add_movie(movies_list):
  print("Enter details of a new movie:\n")
  name=input("Name: ")
  director=input("Diretor: ")
  year=input("Release (year): ")
  budget=input("Budget ($$$): ")
  new_movie_tuple = name,director,year,budget
  movies_list.append(new_movie_tuple)
  return(movies_list)

def remove_movie(movies_delete_1st):
  if len(movies_delete_1st):
    movies_delete_1st.pop(1)
  return(movies_delete_1st)

def print_movies_library(movies_new):
  for x in movies_new:
    print(f"\n{x[0]} \t{x[1]} \t{x[2]} \t{x[3]}")

movies = [
  (
    "\nName",
    "\t\tDirector",
    "\t\tRelease",
    "\tBudget"
  ),
  (
    "John Wick 1",
    "Keanu Reeves",
    2000,
    10000000
  )
]

movies=add_movie(movies)
print_movies_library(movies)
movies = remove_movie(movies)
print_movies_library(movies)