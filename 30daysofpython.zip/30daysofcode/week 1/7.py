name="First Name"#input("Enter your name & surname: ").split(" ")
full_name=name.split(" ")
first_name=full_name[0]
last_name=full_name[1]
print(first_name)
print(last_name)

a=[1, 2, 3, 4, 5]
b=[]
for i in a:
		b.append(str(i))

print(' | '.join(b))


quotes = [
 	"'What a waste my life would be without all the beautiful mistakes I've made.'",
 	"'A bend in the road is not the end of the road... Unless you fail to make the turn.'",
 	"'The very essence of romance is uncertainty.'",
 	"'We are not here to do what has already been done.'"
	 ]

i=1

print("\nUsing slice[1:-1]\n")
for quote in quotes:
	print(str(i)+". "+quote[1:-1])
	i+=1

print("\nUsing .strip()\n")
for quote in quotes:
	print(str(i)+". "+quote.strip("'"))
	i+=1

z="uncertainty"
print(len(z)," is the length of the word.")
print(",".join(z))

#BONUS: from a paragraph, count, number of words & number characters total