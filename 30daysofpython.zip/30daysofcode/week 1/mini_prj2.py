
def print_msg(message, numbers_str):
	print(f"Here You Go:\nWe {msg[0]} on {fizz_on}"+ 
	f" & {msg[1]} on {buzz_on} & {msg[2]} on {fizzbuzz_on}")
	for i in numbers_str:
		print(i)
	return(1)

start=1
stop=100
msg = ["Fizz", "Buzz", "FizzBuzz"]
fizz_on = 3
buzz_on = 5
fizzbuzz_on = str(fizz_on) + " & " + str(buzz_on)
numbers=[]
text=0
for i in range(start, stop+1):
	if i%15 == 0:
		text=msg[2]
		pass
	elif i%5 == 0:
		text=msg[1]
	elif i%3 == 0:
		text=msg[0]
	else:	
		text=i
	numbers.append(text)

print_msg(msg, numbers)