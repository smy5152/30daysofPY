 
 employees = [
    ("Rolf Smith", 35, 8.75),
    ("Anne Pun", 30, 12.50),
    ("Charlie Lee", 50, 15.50),
    ("Bob Smith", 20, 7.00)
]
def wages(one_emp):
	return(one_emp[1]*one_emp[2])

average=0
no_of_emps=len(employees)
for emp in employees:
	average+=emp[2]
	print(f"Hello {emp[0]}, your weekly wages are: ${wages(emp):,.2f}")

average=average/no_of_emps
print("Average Wage: ", average)

no_of_rich_emps=[]
for i in employees:
	if i[2]>average:
		no_of_rich_emps.append(i[0])

print("Earning Above Average Wage: ", no_of_rich_emps)


