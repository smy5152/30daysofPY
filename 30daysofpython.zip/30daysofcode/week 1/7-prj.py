def add_movies():
	while True:
		if input("Would you like to add movies:").strip().lower() == 'y':
			movie_tuple=(input("\nMovie Name:"),int(input("\nBudget:")))
			movies.append(movie_tuple)
			#continue
		else:
			break
		

movies = [
    ("Eternal Sunshine of the Spotless Mind", 20000000),
    ("Memento", 9000000),
    ("Requiem for a Dream", 4500000),
    ("Pirates of the Caribbean: On Stranger Tides", 379000000),
    ("Avengers: Age of Ultron", 365000000),
    ("Avengers: Endgame", 356000000),
    ("Incredibles 2", 200000000)
]

#Help user add more movies before proceeding.
add_movies()

avg_budget = 0
for i in movies:
	avg_budget+=int(i[1])
avg_budget=avg_budget/len(movies)

print("\n____________________________\n")
print(f"Average budget = {avg_budget:,.0f}")
above_avg=[]
for i in movies:
	if int(i[1])>avg_budget:
		above_avg.append(str(i[0])+f" (Over Budget by: ${(int(i[1])-avg_budget):,.0f}/-)")

print(f"\nFollowing: ({len(above_avg)}) movies were over budget:\n"+" , \n".join(above_avg))