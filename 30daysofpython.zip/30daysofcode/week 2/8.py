#exercise 1
print("Welcome! Guess the correct number to win.\n")
correct_num=int(50)

while (guess:=int(input("Guess:")))!=correct_num:
	if(guess<correct_num):
		print("Guess was too low")
	elif(guess>correct_num):
		print("Guess was too high")
	else:
		print("you got it right",correct_num)
		break;

#exercise 2
input_str=input("Enter a string to print by character: ")
skip_print="o"
i=len(input_str)

while i:
	i-=1
	if input_str[i]==skip_print:
		continue
	else:
		print(input_str[i])
	
#exercise 3
primes = []
start=1
stop=100
for dividend in range(start+1, stop+1):
	for divisor in range(start+1, dividend):
		if dividend % divisor == 0:
			break
	else:
		primes.append(str(dividend))

print(", ".join(primes))
