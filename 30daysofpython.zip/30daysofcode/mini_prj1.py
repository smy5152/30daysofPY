while 1:
  print("Enter the following information:")
  name=input("Name: ").strip().lower().title()
  hourly_wage=float(input("Hourly Wage? : ").strip())
  weekly_work_hours=float(input("Hours worked this week? : ").strip())
  earnings=hourly_wage*weekly_work_hours
  print(f"\n Hello, {name}.\n You earn {hourly_wage} per hour.\n Your earnings this week: ${earnings:,.2f}")
  if input("Do you want to continue (Y/N)? : ").strip().lower() == 'n':
    break;