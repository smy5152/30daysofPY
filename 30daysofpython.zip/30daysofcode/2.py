name = input("Enter your name: ")
age = input("Enter your age (years): ")
print("Hello,", name, "you are ", age, "years old.\n")

hourly_wage = input("Please enter your hourly wage: ")
hours_worked = input("How many hours did you work this week? ")

print("Hourly wage: ")
print(hourly_wage)
print("Hours worked: ")
print(hours_worked)